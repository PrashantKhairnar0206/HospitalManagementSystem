package HospitalManagment;
import java.util.Date; 

public class Oppointment {

    private String patient;
    private String doctor;
    private Date date; 

    public Oppointment(String patient, String doctor, Date date) {
        this.patient = patient;
        this.doctor = doctor;
        this.date = date;
    }

    // Getter methods
    public String getPatient() {
        return patient;
    }

    public String getDoctor() {
        return doctor;
    }

    public Date getDate() {
        return date;
    }

    @Override
    public String toString() {
        return "Appointment [Patient=" + patient + ", Doctor=" + doctor + ", Date=" + date + "]";
    }
}
