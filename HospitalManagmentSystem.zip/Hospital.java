package HospitalManagment;
import java.util.ArrayList;
import java.util.List;

public class Hospital {
    private List<Appointment> appointments;

    public Hospital() {
        appointments = new ArrayList<>();
    }

    public void scheduleAppointment(Patient patient, String doctor, String date) {
        Appointment appointment = new Appointment(patient, doctor, date);
        appointments.add(appointment);
        System.out.println("Appointment scheduled for " + patient.getName());
    }

    public void viewAppointments() {
        System.out.println("All Appointments:");
        for (Appointment appointment : appointments) {
            System.out.println(appointment);
        }
    }
}

class Appointment {
    private Patient patient;
    private String doctor;
    private String date;

    public Appointment(Patient patient, String doctor, String date) {
        this.patient = patient;
        this.doctor = doctor;
        this.date = date;
    }

    @Override
    public String toString() {
        return "Appointment: Patient=" + patient.getName() + ", Doctor=" + doctor + ", Date=" + date;
    }
}

