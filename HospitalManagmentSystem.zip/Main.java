package HospitalManagment;

import java.util.Date;

public class Main {

    public static void main(String[] args) {
        
        Date date = new Date();
        Oppointment appointment = new Oppointment("Sushant Chawan", "Dr. Khairnar", date);

        
        System.out.println("Appointment Details:");
        System.out.println(appointment); // This will call the toString() method implicitly
    }
}
